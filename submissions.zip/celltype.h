#ifndef CELLTYPE_H
#define CELLTYPE_H

enum class CellType {
    Normal,
    Firewall,
    ServerPort
};

#endif
