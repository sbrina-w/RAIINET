#ifndef LINKTYPE_H
#define LINKTYPE_H

enum class LinkType {
    Data,
    Virus
};  

#endif
